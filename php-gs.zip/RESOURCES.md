# Useful resources

http://levenshtein.net/
http://levenshtein.net/levenshtein_links.htm